# VisionVoice - Voice Controlled AI Smart Vision (Android)

Offline-first Android app for a Final Year Project: voice commands, "what is this?" (object detection),
text reading (OCR), photo and video by voice, GPS "where am I", reminders, voice notepad,
Bluetooth headset support, and a Premium online AI assistant.

## Quick start
1. Install Android Studio, then File > Open > this folder (wait for Gradle sync).
2. Put `detector.tflite` in `app/src/main/assets/` (see the README.txt in that folder).
3. (Optional, Premium AI) copy the line from `local.properties.example` into `local.properties`.
4. Turn on USB debugging on your phone, connect it, press Run.
5. Allow Camera, Microphone and Notifications. Tap the big button and say "help".

Full explanation: see the Word guide (VisionVoice_App_Guide.docx).

## Folders
- `app/src/main/java/com/fyp/visionvoice/` - all Kotlin source code
- `app/src/main/res/` - screen layout and theme
- `app/src/main/assets/` - put `detector.tflite` here
- `tools/train_custom_detector_colab.ipynb` - Google Colab notebook: dataset + training

Status: written without being compiled or run on a device. Expect to fix small errors on the first build.
