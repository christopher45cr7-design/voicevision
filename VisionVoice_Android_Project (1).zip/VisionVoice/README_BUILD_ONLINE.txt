BUILD THE APP WITHOUT ANDROID STUDIO (GitHub does it for free)
==============================================================
1. github.com > Sign up (free).
2. Click "+" (top right) > New repository > name: visionvoice > Public > Create repository.
3. On the new page click "uploading an existing file".
4. On your laptop open THIS folder (VisionVoice), select EVERYTHING inside it
   (including the folders app, gradle and .github) and drag it onto the GitHub page.
   Wait until all files are listed, then click "Commit changes".
5. Click the "Actions" tab. If GitHub asks, click "I understand my workflows, go ahead and enable them".
   The build "Build APK" starts by itself (or choose Build APK > Run workflow).
6. Wait 5 to 10 minutes. A green tick means success.
7. Click the finished run > scroll down to "Artifacts" > download "VisionVoice-debug-apk".
   Unzip it: app-debug.apk is your app.
8. Send app-debug.apk to your phone (WhatsApp as Document, Google Drive, or USB),
   tap it and allow "Install unknown apps".

If the run shows a red X: open it, click the failed step, and send the red error lines
(or a screenshot) to your helper. Fix the file and upload it again; the build restarts.
