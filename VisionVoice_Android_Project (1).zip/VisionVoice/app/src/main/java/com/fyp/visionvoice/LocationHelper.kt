package com.fyp.visionvoice

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.util.Locale

/** GPS. Satellite positioning works offline; turning coordinates into a street name needs internet. */
class LocationHelper(private val ctx: Context) {

    private val client = LocationServices.getFusedLocationProviderClient(ctx)

    /** True when the phone's Location switch is ON. An app cannot switch it on by itself. */
    fun isLocationOn(): Boolean {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.isLocationEnabled
    }

    @SuppressLint("MissingPermission")
    fun getLocation(onResult: (Location?) -> Unit) {
        val cts = CancellationTokenSource()
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
            .addOnSuccessListener { loc -> onResult(loc) }
            .addOnFailureListener { onResult(null) }
    }

    /** Speaks a street address when online; otherwise speaks the coordinates. */
    fun describe(loc: Location, onText: (String) -> Unit) {
        Thread {
            var text = String.format(Locale.US, "Your position is latitude %.5f, longitude %.5f.", loc.latitude, loc.longitude)
            try {
                if (Geocoder.isPresent()) {
                    @Suppress("DEPRECATION")
                    val list = Geocoder(ctx, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)
                    val line = list?.firstOrNull()?.getAddressLine(0)
                    if (!line.isNullOrBlank()) text = "You are near $line."
                }
            } catch (e: Exception) {
                // Offline or no geocoder: keep the coordinates.
            }
            Handler(Looper.getMainLooper()).post { onText(text) }
        }.start()
    }
}
