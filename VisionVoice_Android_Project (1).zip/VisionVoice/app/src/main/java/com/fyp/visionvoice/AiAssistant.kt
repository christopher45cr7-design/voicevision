package com.fyp.visionvoice

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Online AI question-answering (Premium plan). Needs internet and an OpenAI key.
 *
 * SECURITY NOTE: a key stored inside an app can be extracted from the APK.
 * That is acceptable for a private FYP demo only. For a real release, call your own
 * small server (for example FastAPI) and keep the key on the server.
 */
class AiAssistant {

    fun ask(question: String, onResult: (String) -> Unit) {
        val key = BuildConfig.OPENAI_API_KEY
        if (key.isBlank()) {
            onResult("The AI key is not set. Add OPENAI_API_KEY to the local properties file.")
            return
        }
        Thread {
            val answer = try {
                val conn = (URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 10000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $key")
                }
                val body = JSONObject()
                    .put("model", MODEL)
                    .put(
                        "messages", JSONArray()
                            .put(JSONObject().put("role", "system").put("content", "You are a voice assistant. Reply in at most two short sentences."))
                            .put(JSONObject().put("role", "user").put("content", question))
                    )
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code in 200..299) {
                    JSONObject(text).getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content").trim()
                } else {
                    "The AI service returned an error ($code)."
                }
            } catch (e: Exception) {
                "I could not reach the AI service. Please check the internet."
            }
            Handler(Looper.getMainLooper()).post { onResult(answer) }
        }.start()
    }

    companion object {
        // Use any current low-cost chat model listed in the OpenAI documentation.
        const val MODEL = "gpt-4o-mini"
    }
}
