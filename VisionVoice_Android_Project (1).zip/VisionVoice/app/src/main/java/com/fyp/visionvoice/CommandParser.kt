package com.fyp.visionvoice

import java.util.Locale

/** Every thing the user can ask the app to do. */
enum class Cmd {
    NONE, HELP, TIME, PHOTO, VIDEO_START, VIDEO_STOP, WHAT_IS_THIS, READ_TEXT,
    WHERE_AM_I, REMINDER, LIST_REMINDERS, NOTE_ADD, NOTE_READ, BLUETOOTH, ASK_AI
}

data class Command(val cmd: Cmd, val text: String)

/**
 * Turns the words returned by speech recognition into a command.
 * This is a simple keyword approach: fast, works offline, and easy to explain.
 * A few Urdu keywords are included for the Urdu (ur-PK) recognition mode.
 */
object CommandParser {

    fun normalize(raw: String): String =
        raw.lowercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N}\\s':]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun parse(raw: String): Command {
        val t = normalize(raw)
        if (t.isEmpty()) return Command(Cmd.NONE, t)

        // English keywords must match whole words ("photosynthesis" must not trigger "photo").
        fun has(vararg keys: String): Boolean = keys.any { k ->
            if (k.all { it.code < 128 }) " $t ".contains(" $k ") else t.contains(k)
        }

        val cmd = when {
            has("stop video", "stop recording", "ویڈیو بند") -> Cmd.VIDEO_STOP
            has("record video", "record a video", "start video", "start recording", "ویڈیو بناؤ") -> Cmd.VIDEO_START
            has("my reminders", "list reminders", "show reminders", "show my reminders") -> Cmd.LIST_REMINDERS
            has("remind", "reminder", "alarm", "یاد دلاؤ", "الارم") -> Cmd.REMINDER
            has("read my notes", "my notes", "read notes", "show notes", "میرے نوٹ") -> Cmd.NOTE_READ
            has("note", "notes", "write down", "نوٹ") -> Cmd.NOTE_ADD
            has("bluetooth", "بلوٹوتھ") -> Cmd.BLUETOOTH
            has("take a photo", "take photo", "take a picture", "take picture", "photo", "picture", "تصویر") -> Cmd.PHOTO
            has("what time", "what is the time", "current time", "the time", "وقت") -> Cmd.TIME
            has("where am i", "my location", "location", "میں کہاں") -> Cmd.WHERE_AM_I
            has("what is this", "what's this", "what do you see", "identify", "describe", "یہ کیا") -> Cmd.WHAT_IS_THIS
            has("read", "text", "پڑھ") -> Cmd.READ_TEXT
            has("help", "what can you do", "مدد") -> Cmd.HELP
            else -> Cmd.ASK_AI
        }
        return Command(cmd, t)
    }

    /** "write a note buy milk" -> "buy milk" */
    fun extractNote(t: String): String {
        var s = t.trim()
        s = s.replace(Regex("^(please )?(write down|(write|take|add|save|make) (a |the )?(new )?note)( that| saying)?:? *"), "")
        s = s.replace(Regex("^(please )?(a |the )?(new )?note( that| saying)?:? *"), "")
        return s.trim()
    }
}
