package com.fyp.visionvoice

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.speech.SpeechRecognizer
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    companion object {
        /** false = silent video, so the microphone stays free and "stop video" works by voice. */
        private const val RECORD_VIDEO_AUDIO = false
    }

    private lateinit var previewView: PreviewView
    private lateinit var tvStatus: TextView
    private lateinit var tvOutput: TextView
    private lateinit var tvPlan: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btnMic: Button
    private lateinit var btnLang: Button
    private lateinit var btnBt: Button
    private lateinit var swContinuous: SwitchCompat

    private lateinit var voice: VoiceController
    private lateinit var vision: VisionEngine
    private lateinit var reminders: ReminderManager
    private lateinit var notes: NoteStore
    private lateinit var location: LocationHelper
    private lateinit var plan: PlanManager
    private val ai = AiAssistant()

    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var cameraStarted = false
    private val camExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    private var continuousMode = false
    private var btOn = false
    private var pendingCommand: String? = null

    // ------------------------------------------------------------------ permissions
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            if (hasPermission(Manifest.permission.CAMERA)) startCamera()
            if (!hasPermission(Manifest.permission.RECORD_AUDIO) &&
                !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)
            ) {
                setStatus("Microphone is blocked. Opening app settings - please allow Microphone.")
                openAppSettings()
            }
            val pending = pendingCommand
            pendingCommand = null
            if (pending != null && grants.values.any { it }) handleCommand(pending)
        }

    private fun hasPermission(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun requestStartupPermissions() {
        val needed = mutableListOf<String>()
        if (!hasPermission(Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA)
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        ) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isEmpty()) startCamera() else permLauncher.launch(needed.toTypedArray())
    }

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        previewView = findViewById(R.id.previewView)
        tvStatus = findViewById(R.id.tvStatus)
        tvOutput = findViewById(R.id.tvOutput)
        tvPlan = findViewById(R.id.tvPlan)
        scroll = findViewById(R.id.scroll)
        btnMic = findViewById(R.id.btnMic)
        btnLang = findViewById(R.id.btnLang)
        btnBt = findViewById(R.id.btnBt)
        swContinuous = findViewById(R.id.swContinuous)

        reminders = ReminderManager(this)
        notes = NoteStore(this)
        location = LocationHelper(this)
        plan = PlanManager(this)
        vision = VisionEngine(this)
        voice = VoiceController(
            this,
            { text -> onVoiceResult(text) },
            { status -> setStatus(status) },
            { code -> onVoiceError(code) },
            { onSpeechDone() }
        )

        btnMic.setOnClickListener { onMicClicked() }
        findViewById<Button>(R.id.btnWhat).setOnClickListener { handleCommand("what is this") }
        findViewById<Button>(R.id.btnRead).setOnClickListener { handleCommand("read this text") }
        findViewById<Button>(R.id.btnWhere).setOnClickListener { handleCommand("where am i") }
        btnLang.setOnClickListener { toggleLanguage() }
        btnBt.setOnClickListener { toggleBluetooth() }
        findViewById<Button>(R.id.btnPlan).setOnClickListener {
            plan.togglePremiumDemo()
            updatePlanLabel()
            reply("Plan changed to ${plan.name()}.")
        }
        swContinuous.setOnCheckedChangeListener { _, checked ->
            continuousMode = checked
            if (checked) startListeningSafe() else voice.stopListening()
        }

        updatePlanLabel()
        log("Hello. Tap the microphone and say help to hear what I can do.")
        setStatus(
            if (vision.hasDetector) "Object detector: offline model loaded"
            else "Object detector: basic labels (add detector.tflite for full detection)"
        )
        requestStartupPermissions()
    }

    override fun onPause() {
        super.onPause()
        voice.stopListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        recording?.stop()
        voice.shutdown()
        vision.close()
        camExecutor.shutdown()
    }

    // ------------------------------------------------------------------ small UI helpers
    private fun log(line: String) {
        runOnUiThread {
            tvOutput.append(line + "\n\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun setStatus(text: String) {
        runOnUiThread { tvStatus.text = text }
    }

    /** Shows the answer on screen and speaks it. */
    private fun reply(text: String) {
        runOnUiThread {
            log("App: $text")
            setStatus("Ready")
            voice.speak(text)
        }
    }

    private fun updatePlanLabel() {
        tvPlan.text = "Plan: ${plan.name()}"
    }

    // ------------------------------------------------------------------ voice flow
    private fun onMicClicked() {
        if (recording != null) {
            stopVideo()
            return
        }
        if (voice.isListening) {
            voice.stopListening()
            setStatus("Stopped.")
            return
        }
        startListeningSafe()
    }

    private fun startListeningSafe() {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        voice.startListening()
    }

    private fun onVoiceResult(text: String) {
        handleCommand(text)
    }

    private fun onVoiceError(code: Int) {
        if (continuousMode &&
            (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
        ) restartListeningSoon()
    }

    private fun onSpeechDone() {
        if (continuousMode) restartListeningSoon()
    }

    private fun restartListeningSoon() {
        handler.postDelayed({
            if (continuousMode && !voice.isListening && !voice.isSpeaking) voice.startListening()
        }, 500)
    }

    private fun toggleLanguage() {
        val toUrdu = voice.language == "en-US"
        voice.language = if (toUrdu) "ur-PK" else "en-US"
        btnLang.text = if (toUrdu) "Language: Urdu" else "Language: English"
        setStatus("Voice language: " + if (toUrdu) "Urdu (ur-PK)" else "English (en-US)")
    }

    // ------------------------------------------------------------------ command router
    private fun handleCommand(raw: String) {
        val command = CommandParser.parse(raw)
        log("You: $raw")
        when (command.cmd) {
            Cmd.NONE -> reply("I did not hear anything. Please try again.")
            Cmd.HELP -> reply(
                "You can say: what is this, read this text, take a photo, record video, stop video, " +
                    "where am I, what time is it, remind me to take medicine at 8 pm, write a note buy milk, " +
                    "read my notes, my reminders, or use Bluetooth."
            )
            Cmd.TIME -> reply(SimpleDateFormat("h:mm a 'on' EEEE, d MMMM", Locale.getDefault()).format(Date()))
            Cmd.PHOTO -> takePhoto()
            Cmd.VIDEO_START -> startVideo()
            Cmd.VIDEO_STOP -> stopVideo()
            Cmd.WHAT_IS_THIS -> {
                setStatus("Looking...")
                captureBitmap { bmp -> vision.describe(bmp) { reply(it) } }
            }
            Cmd.READ_TEXT -> {
                setStatus("Reading...")
                captureBitmap { bmp -> vision.readText(bmp) { reply(it) } }
            }
            Cmd.WHERE_AM_I -> whereAmI(raw)
            Cmd.REMINDER -> addReminder(raw)
            Cmd.LIST_REMINDERS -> listReminders()
            Cmd.NOTE_ADD -> addNote(command.text)
            Cmd.NOTE_READ -> readNotes()
            Cmd.BLUETOOTH -> toggleBluetooth()
            Cmd.ASK_AI -> askAi(raw)
        }
    }

    // ------------------------------------------------------------------ camera
    private fun startCamera() {
        if (cameraStarted || !hasPermission(Manifest.permission.CAMERA)) return
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(Quality.HD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
                    )
                    .build()
                val video = VideoCapture.withOutput(recorder)

                provider.unbindAll()
                try {
                    provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture, video)
                    videoCapture = video
                } catch (e: Exception) {
                    // Some phones cannot run preview + photo + video together: keep photo only.
                    provider.unbindAll()
                    provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
                    videoCapture = null
                }
                imageCapture = capture
                cameraStarted = true
            } catch (e: Exception) {
                setStatus("Camera could not start: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** Takes one frame in memory for object detection or OCR. */
    private fun captureBitmap(onBitmap: (Bitmap) -> Unit) {
        val ic = imageCapture
        if (ic == null) {
            reply("The camera is not ready. Please allow camera permission.")
            return
        }
        ic.takePicture(camExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val rotation = image.imageInfo.rotationDegrees
                val bmp = image.toBitmap()
                image.close()
                val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true)
                onBitmap(scaleDown(rotated, 1280))
            }

            override fun onError(exception: ImageCaptureException) {
                reply("I could not take the picture.")
            }
        })
    }

    private fun scaleDown(bmp: Bitmap, maxSide: Int): Bitmap {
        val longest = maxOf(bmp.width, bmp.height)
        if (longest <= maxSide) return bmp
        val scale = maxSide.toFloat() / longest
        return Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
    }

    private fun timestamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun takePhoto() {
        val ic = imageCapture
        if (ic == null) {
            reply("The camera is not ready. Please allow camera permission.")
            return
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VV_" + timestamp())
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/VisionVoice")
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        ic.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                reply("Photo saved in the Pictures, VisionVoice folder.")
            }

            override fun onError(exception: ImageCaptureException) {
                reply("I could not save the photo.")
            }
        })
    }

    private fun startVideo() {
        val vc = videoCapture
        if (vc == null) {
            reply("Video recording is not available on this phone.")
            return
        }
        if (recording != null) {
            reply("I am already recording.")
            return
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VV_" + timestamp())
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/VisionVoice")
        }
        val output = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values)
            .build()
        var pending = vc.output.prepareRecording(this, output)
        if (RECORD_VIDEO_AUDIO && hasPermission(Manifest.permission.RECORD_AUDIO)) {
            pending = pending.withAudioEnabled()
        }
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            if (event is VideoRecordEvent.Finalize) {
                recording = null
                btnMic.text = "Tap and speak"
                reply(if (event.hasError()) "Video recording failed." else "Video saved in the Movies, VisionVoice folder.")
            }
        }
        btnMic.text = "Tap to STOP video"
        reply("Recording started. Say stop video, or tap the button, to finish.")
    }

    private fun stopVideo() {
        val r = recording
        if (r == null) {
            reply("No video is being recorded.")
        } else {
            r.stop()
        }
    }

    // ------------------------------------------------------------------ GPS
    private fun whereAmI(raw: String) {
        val allowed = hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) ||
            hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (!allowed) {
            pendingCommand = raw
            setStatus("Please allow location access.")
            permLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
            return
        }
        if (!location.isLocationOn()) {
            reply("Location is switched off. I am opening the location settings. Please turn it on, then ask again.")
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            return
        }
        setStatus("Finding your location...")
        location.getLocation { loc ->
            if (loc == null) {
                reply("I could not get your location. Please try near a window or outside.")
            } else {
                location.describe(loc) { reply(it) }
            }
        }
    }

    // ------------------------------------------------------------------ Bluetooth
    private fun toggleBluetooth() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !hasPermission(Manifest.permission.BLUETOOTH_CONNECT)
        ) {
            pendingCommand = "use bluetooth"
            permLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT))
            return
        }
        if (btOn) {
            voice.releaseBluetooth()
            btOn = false
            btnBt.text = "Bluetooth: Off"
            reply("Bluetooth headset turned off. Using the phone microphone.")
        } else if (voice.routeToBluetooth()) {
            btOn = true
            btnBt.text = "Bluetooth: On"
            reply("Now using your Bluetooth headset.")
        } else {
            reply("I could not find a Bluetooth headset. Connect your earphones in the phone Bluetooth settings first.")
        }
    }

    // ------------------------------------------------------------------ reminders and notes
    private fun addReminder(raw: String) {
        val parsed = TimeParser.parse(raw)
        if (parsed == null) {
            reply("Please tell me the time, for example: remind me to take medicine at 8 pm, or in 10 minutes.")
            return
        }
        if (!plan.isPremium && reminders.activeCount() >= PlanManager.FREE_MAX_REMINDERS) {
            reply("The Free plan allows ${PlanManager.FREE_MAX_REMINDERS} active reminders. Upgrade to Premium for unlimited reminders.")
            return
        }
        reminders.schedule(parsed.label, parsed.triggerAtMillis)
        val whenText = SimpleDateFormat("h:mm a, EEE d MMM", Locale.getDefault()).format(Date(parsed.triggerAtMillis))
        reply("Okay. Reminder set for $whenText: ${parsed.label}.")
    }

    private fun listReminders() {
        val list = reminders.active()
        if (list.isEmpty()) {
            reply("You have no upcoming reminders.")
            return
        }
        val fmt = SimpleDateFormat("h:mm a, EEE d MMM", Locale.getDefault())
        val text = list.take(5).joinToString(" ") { "${it.label} at ${fmt.format(Date(it.at))}." }
        reply("You have ${list.size} upcoming reminders. $text")
    }

    private fun addNote(text: String) {
        val body = CommandParser.extractNote(text)
        if (body.isBlank()) {
            reply("What should I write? Say: write a note, then your sentence.")
            return
        }
        if (!plan.isPremium && notes.count() >= PlanManager.FREE_MAX_NOTES) {
            reply("The Free plan keeps ${PlanManager.FREE_MAX_NOTES} notes. Upgrade to Premium for unlimited notes.")
            return
        }
        notes.add(body)
        reply("Saved your note: $body")
    }

    private fun readNotes() {
        val all = notes.all()
        if (all.isEmpty()) {
            reply("You have no notes.")
            return
        }
        val text = all.takeLast(5).mapIndexed { i, n -> "Note ${i + 1}: $n." }.joinToString(" ")
        reply("You have ${all.size} notes. $text")
    }

    // ------------------------------------------------------------------ AI assistant (Premium, online)
    private fun askAi(question: String) {
        if (!plan.isPremium) {
            reply(
                "General questions are part of the Premium plan. On the Free plan I can take photos, " +
                    "find objects, read text, set reminders and keep notes. Say help to hear all commands."
            )
            return
        }
        if (!NetworkUtil.isOnline(this)) {
            reply("The AI assistant needs the internet. Please connect and try again.")
            return
        }
        setStatus("Thinking...")
        ai.ask(question) { reply(it) }
    }
}
