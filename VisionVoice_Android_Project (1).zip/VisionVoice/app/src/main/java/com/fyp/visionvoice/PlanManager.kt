package com.fyp.visionvoice

import android.content.Context

/**
 * Free / Premium plans.
 * In this FYP build the plan is switched with a demo button so the idea can be shown.
 * For a real release, replace togglePremiumDemo() with Google Play Billing (see the guide).
 */
class PlanManager(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("plan", Context.MODE_PRIVATE)

    var isPremium: Boolean
        get() = prefs.getBoolean("premium", false)
        private set(value) {
            prefs.edit().putBoolean("premium", value).apply()
        }

    fun togglePremiumDemo() {
        isPremium = !isPremium
    }

    fun name(): String = if (isPremium) "Premium (demo)" else "Free"

    companion object {
        const val FREE_MAX_REMINDERS = 3
        const val FREE_MAX_NOTES = 20
    }
}
