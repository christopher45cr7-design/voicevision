package com.fyp.visionvoice

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * All offline "eyes" of the app.
 *  - OCR: ML Kit text recognition (model is bundled inside the app).
 *  - Objects: MediaPipe detector if assets/detector.tflite exists, otherwise ML Kit image labels.
 */
class VisionEngine(private val context: Context) {

    private val main = Handler(Looper.getMainLooper())
    private val labeler = ImageLabeling.getClient(
        ImageLabelerOptions.Builder().setConfidenceThreshold(0.6f).build()
    )
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var detector: ObjectDetector? = null

    val hasDetector: Boolean get() = detector != null

    init {
        try {
            context.assets.open(MODEL_FILE).close()   // throws if the file is not there
            val base = BaseOptions.builder().setModelAssetPath(MODEL_FILE).build()
            val options = ObjectDetector.ObjectDetectorOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.IMAGE)
                .setMaxResults(6)
                .setScoreThreshold(0.45f)
                .build()
            detector = ObjectDetector.createFromOptions(context, options)
        } catch (e: Throwable) {
            detector = null
        }
    }

    /** "What is this?" */
    fun describe(bitmap: Bitmap, onResult: (String) -> Unit) {
        val det = detector
        if (det == null) {
            labelFallback(bitmap, onResult)
            return
        }
        Thread {
            val text: String? = try {
                val result = det.detect(BitmapImageBuilder(bitmap).build())
                val names = result.detections().mapNotNull { it.categories().firstOrNull()?.categoryName() }
                summarize(names)
            } catch (e: Throwable) {
                null
            }
            main.post {
                if (text != null) onResult(text) else labelFallback(bitmap, onResult)
            }
        }.start()
    }

    private fun labelFallback(bitmap: Bitmap, onResult: (String) -> Unit) {
        labeler.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { labels ->
                val names = labels.sortedByDescending { it.confidence }.take(3).map { it.text.lowercase() }
                onResult(
                    if (names.isEmpty()) "I am not sure what this is."
                    else "This looks like " + names.joinToString(", ") + "."
                )
            }
            .addOnFailureListener { onResult("Sorry, I could not analyse the picture.") }
    }

    /** "Read this text" */
    fun readText(bitmap: Bitmap, onResult: (String) -> Unit) {
        textRecognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { r ->
                val t = r.text.trim().replace(Regex("\\s+"), " ")
                onResult(if (t.isEmpty()) "I could not find any text." else t)
            }
            .addOnFailureListener { onResult("Sorry, I could not read the text.") }
    }

    private fun summarize(names: List<String>): String {
        if (names.isEmpty()) return "I could not see any known object."
        val parts = names.groupingBy { it }.eachCount().map { (name, count) ->
            if (count == 1) "a $name" else "$count " + (if (name == "person") "people" else name + "s")
        }
        val text = if (parts.size == 1) parts[0]
        else parts.dropLast(1).joinToString(", ") + " and " + parts.last()
        return "I can see $text."
    }

    fun close() {
        labeler.close()
        textRecognizer.close()
        detector?.close()
    }

    companion object {
        const val MODEL_FILE = "detector.tflite"
    }
}
