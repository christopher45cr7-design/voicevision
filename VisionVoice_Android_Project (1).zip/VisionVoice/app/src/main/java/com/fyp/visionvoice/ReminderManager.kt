package com.fyp.visionvoice

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Alarms and reminders. They work with no internet because Android's AlarmManager is built in. */
class ReminderManager(private val ctx: Context) {

    data class Item(val id: Int, val at: Long, val label: String)

    private val prefs = ctx.getSharedPreferences("reminders", Context.MODE_PRIVATE)
    private val alarmManager = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun load(): MutableList<Item> {
        val set = prefs.getStringSet("items", emptySet()) ?: emptySet()
        val out = mutableListOf<Item>()
        for (s in set) {
            val p = s.split("|", limit = 3)
            val id = p.getOrNull(0)?.toIntOrNull() ?: continue
            val at = p.getOrNull(1)?.toLongOrNull() ?: continue
            val label = p.getOrNull(2) ?: continue
            out.add(Item(id, at, label))
        }
        return out
    }

    private fun save(items: List<Item>) {
        val set = items.map { "${it.id}|${it.at}|${it.label.replace("|", " ")}" }.toSet()
        prefs.edit().putStringSet("items", set).apply()
    }

    /** Reminders that have not rung yet, earliest first. */
    fun active(): List<Item> =
        load().filter { it.at > System.currentTimeMillis() }.sortedBy { it.at }

    fun activeCount(): Int = active().size

    /** Returns true when the alarm is exact; false when Android only allows a slightly inexact alarm. */
    fun schedule(label: String, atMillis: Long): Boolean {
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val items = active().toMutableList()
        val item = Item(id, atMillis, label)
        items.add(item)
        save(items)
        return setAlarm(item)
    }

    /** Called after the phone restarts, because Android clears alarms on reboot. */
    fun rescheduleAll() {
        for (item in active()) setAlarm(item)
    }

    private fun setAlarm(item: Item): Boolean {
        val intent = Intent(ctx, ReminderReceiver::class.java)
            .putExtra("label", item.label)
            .putExtra("id", item.id)
        val pi = PendingIntent.getBroadcast(
            ctx, item.id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()
        if (canExact) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.at, pi)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.at, pi)
        }
        return canExact
    }
}

/** Rings when a reminder time arrives (shows a notification with the alarm sound). */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val label = intent.getStringExtra("label") ?: "Reminder"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channel = NotificationChannel("reminders", "Reminders", NotificationManager.IMPORTANCE_HIGH)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        channel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), attrs)
        nm.createNotificationChannel(channel)

        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, "reminders")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Reminder")
            .setContentText(label)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        val allowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (allowed) nm.notify(System.currentTimeMillis().toInt(), notification)
    }
}

/** Puts the alarms back after the phone is restarted. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            ReminderManager(context).rescheduleAll()
        }
    }
}
