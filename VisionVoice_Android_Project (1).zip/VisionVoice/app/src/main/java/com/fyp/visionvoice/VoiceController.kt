package com.fyp.visionvoice

import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Microphone -> text (Android SpeechRecognizer) and text -> voice (Android TextToSpeech).
 *
 * How the app "detects" your voice: when startListening() is called, Android opens the
 * microphone, its speech service detects when you start and stop talking, and returns the
 * words. EXTRA_PREFER_OFFLINE asks for the on-device language pack so it can work without internet.
 */
class VoiceController(
    private val ctx: Context,
    private val onResultText: (String) -> Unit,
    private val onStatusText: (String) -> Unit,
    private val onRecognizerError: (Int) -> Unit,
    private val onSpeechFinished: () -> Unit
) {
    var language: String = "en-US"
    var preferOffline: Boolean = true

    var isListening: Boolean = false
        private set
    var isSpeaking: Boolean = false
        private set

    private val main = Handler(Looper.getMainLooper())
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale.US)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isSpeaking = true
                    }

                    override fun onDone(utteranceId: String?) {
                        finishSpeaking()
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        finishSpeaking()
                    }
                })
                ttsReady = true
            } else {
                onStatusText("Text-to-speech is not available on this phone.")
            }
        }
    }

    private fun finishSpeaking() {
        isSpeaking = false
        main.post { onSpeechFinished() }
    }

    // ------------------------------------------------------------------ speaking
    fun speak(text: String) {
        stopListening()
        if (!ttsReady) {
            main.post { onSpeechFinished() }
            return
        }
        val t = if (text.length > 3500) text.substring(0, 3500) else text
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "vv-" + System.nanoTime())
    }

    // ------------------------------------------------------------------ listening
    fun startListening() {
        if (isSpeaking || isListening) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onStatusText("Speech recognition is not available. Install or enable the Google app.")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).also { it.setRecognitionListener(listener) }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        isListening = true
        onStatusText("Listening...")
        recognizer?.startListening(intent)
    }

    fun stopListening() {
        if (isListening) {
            recognizer?.cancel()
            isListening = false
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {
            onStatusText("Hearing you...")
        }

        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            onStatusText("Processing...")
        }

        override fun onError(error: Int) {
            isListening = false
            onStatusText(errorText(error))
            onRecognizerError(error)
        }

        override fun onResults(results: Bundle?) {
            isListening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            onResultText(text)
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun errorText(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH -> "I did not understand. Please try again."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I did not hear anything."
        SpeechRecognizer.ERROR_AUDIO -> "Microphone problem."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "Network problem. Download the offline speech pack (see the guide)."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer is busy. Try again."
        12, 13 -> "This language pack is not installed. Download it in the Google app voice settings."
        else -> "Voice error ($code)."
    }

    // ------------------------------------------------------------------ Bluetooth headset
    /** Sends the microphone and sound to a connected Bluetooth headset. Returns false if none is connected. */
    @Suppress("DEPRECATION")
    fun routeToBluetooth(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val device = audio.availableCommunicationDevices.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
            }
            if (device == null) {
                false
            } else {
                audio.mode = AudioManager.MODE_IN_COMMUNICATION
                audio.setCommunicationDevice(device)
            }
        } else {
            if (audio.isBluetoothScoAvailableOffCall) {
                audio.mode = AudioManager.MODE_IN_COMMUNICATION
                audio.startBluetoothSco()
                audio.isBluetoothScoOn = true
                true
            } else {
                false
            }
        }
    }

    @Suppress("DEPRECATION")
    fun releaseBluetooth() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            audio.clearCommunicationDevice()
        } else {
            audio.stopBluetoothSco()
            audio.isBluetoothScoOn = false
        }
        audio.mode = AudioManager.MODE_NORMAL
    }

    fun shutdown() {
        stopListening()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        releaseBluetooth()
    }
}
