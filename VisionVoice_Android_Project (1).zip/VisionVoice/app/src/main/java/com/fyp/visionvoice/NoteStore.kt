package com.fyp.visionvoice

import android.content.Context
import org.json.JSONArray

/** Voice notepad. Notes are saved on the phone (works fully offline). */
class NoteStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("notes", Context.MODE_PRIVATE)

    fun all(): List<String> {
        val arr = JSONArray(prefs.getString("list", "[]"))
        return List(arr.length()) { arr.getString(it) }
    }

    fun count(): Int = all().size

    fun add(text: String) {
        val arr = JSONArray(prefs.getString("list", "[]"))
        arr.put(text)
        prefs.edit().putString("list", arr.toString()).apply()
    }
}
