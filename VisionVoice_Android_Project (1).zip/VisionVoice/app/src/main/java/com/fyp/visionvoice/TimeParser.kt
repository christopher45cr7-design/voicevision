package com.fyp.visionvoice

import java.util.Calendar
import java.util.Locale

/**
 * Understands simple spoken times without internet:
 *   "at 8 pm", "at 8:30 am", "at 20:15", "in 10 minutes", "in 2 hours", "tomorrow at 7 am".
 */
object TimeParser {

    data class Result(val triggerAtMillis: Long, val label: String)

    fun parse(raw: String, now: Calendar = Calendar.getInstance()): Result? {
        val t = raw.lowercase(Locale.ROOT).replace(".", "").replace(",", " ")

        // "in 10 minutes" / "in 2 hours"
        Regex("""in (\d+) (minutes|minute|mins|min|hours|hour|hrs|hr)""").find(t)?.let { m ->
            val n = m.groupValues[1].toInt()
            val cal = now.clone() as Calendar
            if (m.groupValues[2].startsWith("h")) cal.add(Calendar.HOUR_OF_DAY, n)
            else cal.add(Calendar.MINUTE, n)
            return Result(cal.timeInMillis, label(t, m.value))
        }

        var hour = -1
        var minute = 0
        var phrase = ""

        // "8 pm", "8:30 am"
        Regex("""(\d{1,2})(?::(\d{2}))?\s?(am|pm)""").find(t)?.let { m ->
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            val pm = m.groupValues[3] == "pm"
            if (h in 1..12 && min in 0..59) {
                if (pm && h < 12) h += 12
                if (!pm && h == 12) h = 0
                hour = h
                minute = min
                phrase = m.value
            }
        }

        // "at 20:15" (24-hour)
        if (hour < 0) {
            Regex("""at (\d{1,2}):(\d{2})""").find(t)?.let { m ->
                val h = m.groupValues[1].toInt()
                val min = m.groupValues[2].toInt()
                if (h in 0..23 && min in 0..59) {
                    hour = h
                    minute = min
                    phrase = m.value
                }
            }
        }

        if (hour < 0) return null

        val cal = now.clone() as Calendar
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (t.contains("tomorrow") || cal.timeInMillis <= now.timeInMillis) {
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        return Result(cal.timeInMillis, label(t, phrase))
    }

    private fun label(t: String, phrase: String): String {
        // remove the time phrase together with a word like "at" that comes just before it
        var s = t.replace(Regex("(\\bat\\s+)?" + Regex.escape(phrase)), " ")
        s = s.replace(
            Regex("\\b(remind me to|remind me|remind|set a reminder to|set a reminder|set an alarm for|set an alarm|set alarm|reminder|alarm|please|tomorrow|today)\\b"),
            " "
        )
        s = s.replace(Regex("\\s+"), " ").trim()
        s = s.removePrefix("to ").removeSuffix(" at").removeSuffix(" on").trim()
        return if (s.isBlank()) "your reminder" else s
    }
}
