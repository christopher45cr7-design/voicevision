PUT YOUR OBJECT-DETECTION MODEL HERE
====================================
File name must be exactly:  detector.tflite

Option A (easiest, no training): download the official MediaPipe EfficientDet-Lite0
model (trained on COCO, 80 everyday object classes) and rename it to detector.tflite:

  https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/float32/1/efficientdet_lite0.tflite

(If that link ever changes, open the MediaPipe "Object Detector" page on
developers.google.com/mediapipe and use the EfficientDet-Lite0 link in its Models section.)

Option B (your own classes): train with the Colab notebook in the "tools" folder
(train_custom_detector_colab.ipynb), download model.tflite and rename it detector.tflite.

If this file is missing the app still works: it uses the built-in offline image
labels (ML Kit) instead of full object detection.
